package com.javatpoint.springbootapplicationrun;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootApplicationRunApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootApplicationRunApplication.class, args);
	}

}
